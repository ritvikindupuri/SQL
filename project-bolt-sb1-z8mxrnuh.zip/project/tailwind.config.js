/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        teal: {
          500: '#0ED3D3',
          600: '#0BAAAA',
          700: '#089292',
        },
        purple: {
          500: '#8A3FFC',
          600: '#7023EB',
          700: '#5B14D1',
        },
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      boxShadow: {
        'glow': '0 0 15px rgba(14, 211, 211, 0.5)',
      },
    },
  },
  plugins: [],
};