import React, { useState, useEffect } from 'react';
import { Shield, Target, FileText, AlertTriangle } from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import StatCard from '../components/dashboard/StatCard';
import SQLConsole from '../components/sqltesting/SQLConsole';
import VulnerabilityCard from '../components/sqltesting/VulnerabilityCard';
import TutorialCard from '../components/education/TutorialCard';
import { Vulnerability, Tutorial } from '../types';

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState({
    totalTests: 0,
    successRate: 0,
    reportsGenerated: 0,
    vulnerabilitiesFound: 0
  });
  
  const [vulnerabilities, setVulnerabilities] = useState<Vulnerability[]>([]);
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [loading, setLoading] = useState(true);

  // Function to update stats based on SQL query results
  const updateStats = (isVulnerable: boolean) => {
    setStats(prev => ({
      totalTests: prev.totalTests + 1,
      successRate: Math.round((prev.totalTests * (prev.successRate / 100) + (isVulnerable ? 0 : 1)) / (prev.totalTests + 1) * 100),
      reportsGenerated: prev.reportsGenerated + (isVulnerable ? 1 : 0),
      vulnerabilitiesFound: prev.vulnerabilitiesFound + (isVulnerable ? 1 : 0)
    }));
  };

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-teal-500"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-gray-400">Welcome back. Here's your security testing overview.</p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Tests Run"
          value={stats.totalTests}
          icon={<Shield size={24} className="text-teal-500" />}
        />
        <StatCard 
          title="Success Rate"
          value={`${stats.successRate}%`}
          icon={<Target size={24} className="text-purple-500" />}
        />
        <StatCard 
          title="Reports Generated"
          value={stats.reportsGenerated}
          icon={<FileText size={24} className="text-teal-500" />}
        />
        <StatCard 
          title="Vulnerabilities Found"
          value={stats.vulnerabilitiesFound}
          icon={<AlertTriangle size={24} className="text-red-500" />}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <SQLConsole onQueryExecuted={updateStats} />
        </div>
        
        <div>
          <h2 className="text-xl font-bold mb-4">Recent Vulnerabilities</h2>
          {vulnerabilities.length > 0 ? (
            <>
              {vulnerabilities.map(vulnerability => (
                <VulnerabilityCard 
                  key={vulnerability.id} 
                  vulnerability={vulnerability} 
                />
              ))}
            </>
          ) : (
            <div className="text-gray-400 text-sm">No vulnerabilities detected yet. Run some SQL queries to test for vulnerabilities.</div>
          )}
        </div>
      </div>
      
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Recommended Tutorials</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tutorials.length > 0 ? (
            tutorials.map(tutorial => (
              <TutorialCard key={tutorial.id} tutorial={tutorial} />
            ))
          ) : (
            <div className="text-gray-400 text-sm">Complete some SQL tests to get personalized tutorial recommendations.</div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;