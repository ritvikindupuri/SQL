import React from 'react';
import DashboardLayout from '../components/layout/DashboardLayout';
import TutorialCard from '../components/education/TutorialCard';

const Learn: React.FC = () => {
  const tutorials = [
    {
      id: 1,
      title: 'SQL Injection Basics',
      description: 'Learn the fundamentals of SQL injection attacks and how to prevent them.',
      difficulty: 'beginner' as const,
      duration: '30 mins',
      imageUrl: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg'
    },
    {
      id: 2,
      title: 'Advanced SQL Security',
      description: 'Deep dive into advanced SQL security techniques and best practices.',
      difficulty: 'advanced' as const,
      duration: '1 hour',
      imageUrl: 'https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg'
    }
  ];

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Learn</h1>
        <p className="text-gray-400">Enhance your SQL security knowledge with our tutorials.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tutorials.map(tutorial => (
          <TutorialCard key={tutorial.id} tutorial={tutorial} />
        ))}
      </div>
    </DashboardLayout>
  );
};

export default Learn;