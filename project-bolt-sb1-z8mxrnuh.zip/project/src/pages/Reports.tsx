import React from 'react';
import DashboardLayout from '../components/layout/DashboardLayout';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import { FileText, Download } from 'lucide-react';

const Reports: React.FC = () => {
  const reports = [
    {
      id: 1,
      title: 'Monthly Security Scan',
      date: '2024-03-15',
      type: 'Security Audit',
      status: 'completed'
    },
    {
      id: 2,
      title: 'Vulnerability Assessment',
      date: '2024-03-10',
      type: 'Assessment',
      status: 'completed'
    }
  ];

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Reports</h1>
        <p className="text-gray-400">View and download security reports.</p>
      </div>
      <div className="grid gap-4">
        {reports.map(report => (
          <Card key={report.id}>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <FileText className="text-teal-500" size={24} />
                <div>
                  <h3 className="text-lg font-medium text-white">{report.title}</h3>
                  <p className="text-sm text-gray-400">{report.date}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Badge variant="secondary">{report.type}</Badge>
                <button className="text-teal-500 hover:text-teal-400">
                  <Download size={20} />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </DashboardLayout>
  );
};

export default Reports;