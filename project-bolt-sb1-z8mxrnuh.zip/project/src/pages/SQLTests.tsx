import React, { useState } from 'react';
import DashboardLayout from '../components/layout/DashboardLayout';
import SQLConsole from '../components/sqltesting/SQLConsole';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import { BookOpen } from 'lucide-react';

const SQLTests: React.FC = () => {
  const [testCount, setTestCount] = useState(0);
  const [vulnerableCount, setVulnerableCount] = useState(0);

  const handleQueryExecuted = (isVulnerable: boolean) => {
    setTestCount(prev => prev + 1);
    if (isVulnerable) {
      setVulnerableCount(prev => prev + 1);
    }
  };

  const examples = [
    {
      title: 'Basic SQL Injection',
      query: "SELECT * FROM users WHERE username = '' OR '1'='1'",
      description: 'This example demonstrates a basic SQL injection that always evaluates to true'
    },
    {
      title: 'Union-Based Injection',
      query: "SELECT name FROM products WHERE id = 1 UNION SELECT password FROM users",
      description: 'Attempts to retrieve sensitive data by joining with another table'
    },
    {
      title: 'Comment-Based Injection',
      query: "SELECT * FROM users WHERE username = 'admin'--' AND password = 'anything'",
      description: 'Uses comments to modify query logic'
    }
  ];

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">SQL Tests</h1>
        <p className="text-gray-400">Test your queries for SQL injection vulnerabilities.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card>
          <div className="text-center">
            <h3 className="text-lg font-medium text-white">Total Tests</h3>
            <p className="text-3xl font-bold text-teal-500 mt-2">{testCount}</p>
          </div>
        </Card>
        <Card>
          <div className="text-center">
            <h3 className="text-lg font-medium text-white">Vulnerabilities Found</h3>
            <p className="text-3xl font-bold text-red-500 mt-2">{vulnerableCount}</p>
          </div>
        </Card>
        <Card>
          <div className="text-center">
            <h3 className="text-lg font-medium text-white">Success Rate</h3>
            <p className="text-3xl font-bold text-purple-500 mt-2">
              {testCount === 0 ? '0' : Math.round(((testCount - vulnerableCount) / testCount) * 100)}%
            </p>
          </div>
        </Card>
      </div>

      <SQLConsole onQueryExecuted={handleQueryExecuted} />

      <div className="mt-8">
        <div className="flex items-center mb-4">
          <BookOpen className="text-teal-500 mr-2" size={20} />
          <h2 className="text-xl font-bold">Example Injection Patterns</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {examples.map((example, index) => (
            <Card key={index}>
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-white">{example.title}</h3>
                  <Badge variant="danger">Vulnerable</Badge>
                </div>
                <p className="text-sm text-gray-400 mb-4">{example.description}</p>
                <code className="text-sm bg-gray-800 p-3 rounded-md font-mono text-teal-400 break-all">
                  {example.query}
                </code>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default SQLTests;