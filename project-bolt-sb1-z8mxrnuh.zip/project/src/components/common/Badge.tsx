import React from 'react';

type BadgeVariant = 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({ 
  children, 
  variant = 'default',
  className = '' 
}) => {
  const variantStyles = {
    default: 'bg-gray-700 text-gray-200',
    primary: 'bg-teal-500 bg-opacity-20 text-teal-300',
    secondary: 'bg-purple-600 bg-opacity-20 text-purple-300',
    success: 'bg-green-500 bg-opacity-20 text-green-300',
    warning: 'bg-yellow-500 bg-opacity-20 text-yellow-300',
    danger: 'bg-red-500 bg-opacity-20 text-red-300'
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variantStyles[variant]} ${className}`}>
      {children}
    </span>
  );
};

export default Badge;