import React from 'react';

interface CardProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  footer?: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ 
  children, 
  title, 
  className = '', 
  footer 
}) => {
  return (
    <div className={`bg-gray-800 rounded-lg overflow-hidden shadow-lg border border-gray-700 ${className}`}>
      {title && (
        <div className="px-6 py-4 border-b border-gray-700">
          <h3 className="text-lg font-medium text-white">{title}</h3>
        </div>
      )}
      
      <div className="px-6 py-4">
        {children}
      </div>
      
      {footer && (
        <div className="px-6 py-3 bg-gray-900 border-t border-gray-700">
          {footer}
        </div>
      )}
    </div>
  );
};

export default Card;