import React, { useState } from 'react';
import { Terminal, Play, AlertCircle, CheckCircle2, Copy, Save, History } from 'lucide-react';
import Button from '../common/Button';
import Card from '../common/Card';
import Badge from '../common/Badge';

interface QueryResult {
  columns: string[];
  rows: any[];
}

interface QueryHistory {
  query: string;
  timestamp: string;
  isVulnerable: boolean;
}

interface SQLConsoleProps {
  onQueryExecuted: (isVulnerable: boolean) => void;
}

const SQLConsole: React.FC<SQLConsoleProps> = ({ onQueryExecuted }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<QueryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isVulnerable, setIsVulnerable] = useState<boolean | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [queryHistory, setQueryHistory] = useState<QueryHistory[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const executeQuery = async () => {
    if (!query.trim()) {
      setError('Query cannot be empty');
      return;
    }

    setIsExecuting(true);
    setError(null);
    setResults(null);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      const lowerQuery = query.toLowerCase();
      let queryResult: QueryResult | null = null;
      let vulnerable = false;

      // Enhanced SQL injection detection patterns
      if (
        lowerQuery.includes('--') || 
        lowerQuery.includes(';') || 
        lowerQuery.includes('/*') || 
        lowerQuery.includes('*/') ||
        lowerQuery.includes('xp_') ||
        /\bor\s+['"]\d+['"]\s*=\s*['"]\d+['"]/.test(lowerQuery) ||
        /\bunion\s+(?:all\s+)?select\b/i.test(lowerQuery)
      ) {
        vulnerable = true;
        queryResult = {
          columns: ['id', 'username', 'password', 'email'],
          rows: [
            { id: 1, username: 'admin', password: 'hashed_password_1', email: 'admin@company.com' },
            { id: 2, username: 'system', password: 'hashed_password_2', email: 'system@company.com' }
          ]
        };
      } else if (lowerQuery.includes('drop') || lowerQuery.includes('truncate')) {
        vulnerable = true;
        queryResult = {
          columns: ['status', 'affected_rows'],
          rows: [{ status: 'Operation completed', affected_rows: 'All' }]
        };
      } else {
        queryResult = {
          columns: ['status', 'message'],
          rows: [{ status: 'Success', message: 'Query executed safely' }]
        };
      }

      // Add to history
      setQueryHistory(prev => [{
        query,
        timestamp: new Date().toISOString(),
        isVulnerable: vulnerable
      }, ...prev].slice(0, 10));

      setResults(queryResult);
      setIsVulnerable(vulnerable);
      onQueryExecuted(vulnerable);
    } catch (err) {
      setError('Error executing query: ' + (err instanceof Error ? err.message : String(err)));
      setIsVulnerable(null);
    } finally {
      setIsExecuting(false);
    }
  };

  const copyQuery = (queryText: string) => {
    navigator.clipboard.writeText(queryText);
  };

  return (
    <Card title="SQL Injection Testing Console" className="mb-6">
      <div className="flex items-center mb-2 space-x-2">
        <Terminal size={18} className="text-teal-500" />
        <h3 className="text-md font-mono">SQL Query</h3>
        <Badge variant="secondary">Test Environment: Active</Badge>
        <Button 
          variant="ghost" 
          size="sm"
          icon={<History size={16} />}
          onClick={() => setShowHistory(!showHistory)}
        >
          History
        </Button>
      </div>
      
      {showHistory && queryHistory.length > 0 && (
        <div className="mb-4 p-3 bg-gray-800 rounded-md">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Recent Queries</h4>
          <div className="space-y-2">
            {queryHistory.map((item, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-2">
                  <code className="text-gray-400">{item.query.slice(0, 50)}{item.query.length > 50 ? '...' : ''}</code>
                  <Badge variant={item.isVulnerable ? 'danger' : 'success'} className="text-xs">
                    {item.isVulnerable ? 'Vulnerable' : 'Safe'}
                  </Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => copyQuery(item.query)}
                    className="text-gray-400 hover:text-white"
                  >
                    <Copy size={14} />
                  </button>
                  <button 
                    onClick={() => setQuery(item.query)}
                    className="text-teal-500 hover:text-teal-400"
                  >
                    <Save size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="relative">
        <textarea
          className="w-full h-32 p-3 bg-gray-900 text-white font-mono text-sm rounded-md border border-gray-700 focus:border-teal-500 focus:ring focus:ring-teal-500 focus:ring-opacity-50"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your SQL query here..."
          spellCheck="false"
        />
      </div>
      
      <div className="mt-3 flex items-center justify-between">
        <div className="flex space-x-2">
          <Button 
            variant="primary"
            size="md"
            icon={<Play size={16} />}
            isLoading={isExecuting}
            onClick={executeQuery}
          >
            Execute Query
          </Button>
          
          <Button
            variant="ghost"
            size="md"
            onClick={() => setQuery('')}
          >
            Clear
          </Button>
        </div>
        
        {isVulnerable !== null && (
          <Badge 
            variant={isVulnerable ? 'danger' : 'success'}
            className="flex items-center"
          >
            {isVulnerable ? (
              <>
                <AlertCircle size={12} className="mr-1" />
                Vulnerable
              </>
            ) : (
              <>
                <CheckCircle2 size={12} className="mr-1" />
                Secure
              </>
            )}
          </Badge>
        )}
      </div>
      
      {error && (
        <div className="mt-4 p-3 bg-red-900 bg-opacity-20 border border-red-700 rounded-md text-red-400">
          {error}
        </div>
      )}
      
      {results && (
        <div className="mt-4">
          <div className="border border-gray-700 rounded-md overflow-hidden">
            <div className="bg-gray-800 px-4 py-2 text-sm font-medium text-gray-300 flex justify-between items-center">
              <span>Query Results {results.rows.length > 0 ? `(${results.rows.length} rows)` : ''}</span>
              <Button
                variant="ghost"
                size="sm"
                icon={<Copy size={14} />}
                onClick={() => copyQuery(JSON.stringify(results, null, 2))}
              >
                Copy Results
              </Button>
            </div>
            
            {results.rows.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-700">
                  <thead className="bg-gray-800">
                    <tr>
                      {results.columns.map((column) => (
                        <th 
                          key={column}
                          className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider"
                        >
                          {column}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-gray-900 divide-y divide-gray-800">
                    {results.rows.map((row, rowIndex) => (
                      <tr key={rowIndex}>
                        {Object.values(row).map((value, cellIndex) => (
                          <td 
                            key={cellIndex}
                            className="px-6 py-4 whitespace-nowrap text-sm text-gray-300"
                          >
                            {String(value)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-4 text-sm text-gray-400">No results found</div>
            )}
          </div>
          
          {isVulnerable && (
            <div className="mt-4 p-4 bg-red-900 bg-opacity-20 border border-red-700 rounded-md">
              <h4 className="text-red-300 font-medium">Vulnerability Detected</h4>
              <p className="mt-1 text-sm text-red-300">
                This query appears to be vulnerable to SQL injection attacks. The application is not properly validating or sanitizing user input before constructing SQL queries.
              </p>
              <h5 className="mt-3 text-red-300 font-medium">Recommendations:</h5>
              <ul className="mt-1 text-sm text-red-300 list-disc list-inside space-y-1">
                <li>Use parameterized queries or prepared statements</li>
                <li>Implement input validation and sanitization</li>
                <li>Apply the principle of least privilege for database users</li>
                <li>Consider using an ORM with built-in SQL injection protection</li>
              </ul>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};

export default SQLConsole;