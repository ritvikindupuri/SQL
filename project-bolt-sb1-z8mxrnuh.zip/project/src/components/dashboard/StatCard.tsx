import React from 'react';
import Card from '../common/Card';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change?: {
    value: string | number;
    positive: boolean;
  };
  className?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  change,
  className = '',
}) => {
  return (
    <Card className={`${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-400">{title}</p>
          <p className="mt-1 text-2xl font-semibold text-white">{value}</p>
          
          {change && (
            <p className={`mt-1 text-sm ${change.positive ? 'text-green-500' : 'text-red-500'}`}>
              {change.positive ? '↑' : '↓'} {change.value}
            </p>
          )}
        </div>
        
        <div className={`p-3 rounded-full bg-opacity-20 ${title.includes('Vulnerabilities') ? 'bg-red-500' : title.includes('Tests') ? 'bg-teal-500' : 'bg-purple-500'}`}>
          {icon}
        </div>
      </div>
    </Card>
  );
};

export default StatCard;