import React from 'react';
import { BookOpen } from 'lucide-react';
import Card from '../common/Card';
import Badge from '../common/Badge';

interface Tutorial {
  id: number;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  imageUrl: string;
}

interface TutorialCardProps {
  tutorial: Tutorial;
}

const TutorialCard: React.FC<TutorialCardProps> = ({ tutorial }) => {
  const difficultyVariant = {
    beginner: 'primary',
    intermediate: 'secondary',
    advanced: 'danger'
  } as const;

  return (
    <Card className="h-full transition-all hover:shadow-lg">
      <div className="flex flex-col h-full">
        <div className="relative h-48 -mx-6 -mt-4 mb-4 overflow-hidden">
          <img 
            src={tutorial.imageUrl} 
            alt={tutorial.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
          <Badge 
            variant={difficultyVariant[tutorial.difficulty]}
            className="absolute top-3 right-3"
          >
            {tutorial.difficulty}
          </Badge>
        </div>
        
        <h3 className="text-lg font-medium text-white mb-2">{tutorial.title}</h3>
        <p className="text-gray-400 text-sm mb-4 flex-grow">{tutorial.description}</p>
        
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-gray-700">
          <span className="flex items-center text-gray-400 text-xs">
            <BookOpen size={14} className="mr-1" />
            {tutorial.duration}
          </span>
          
          <button className="text-sm text-teal-500 hover:text-teal-400 font-medium transition-colors">
            Start Tutorial
          </button>
        </div>
      </div>
    </Card>
  );
};

export default TutorialCard;