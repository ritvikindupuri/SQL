export interface User {
  id: string;
  username: string;
  email: string;
}

export interface SQLTest {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  status: 'completed' | 'in-progress' | 'failed';
}

export interface Vulnerability {
  id: string;
  name: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  detectedAt: string;
  status: 'open' | 'fixed' | 'in-review';
}

export interface Tutorial {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  imageUrl: string;
  completed?: boolean;
}

export interface Report {
  id: string;
  title: string;
  generatedAt: string;
  format: 'pdf' | 'csv' | 'json';
  size: string;
}